// This component has been retired in favor of BuildupPanel and SentimentAnalysis components.
export default () => null;